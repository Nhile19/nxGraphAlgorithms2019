import networkx as nx
def neighbors(G,V):
    return list(nx.neighbors(G,V))
"""

def set_neighbors(G,S) #G, S = list of vertices, return set of neighbors of verticies
    N = []
    for x in S:
        N.append() ??


"""

