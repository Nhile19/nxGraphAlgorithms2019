import networkx as nx
from itertools import combinations
from functions.global_properties import V
from functions.local_properties import neighbors
