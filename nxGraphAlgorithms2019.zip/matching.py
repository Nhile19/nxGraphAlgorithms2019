import networkx as nx

def is_matching(G,s):
    return nx.is_matching(G, s)